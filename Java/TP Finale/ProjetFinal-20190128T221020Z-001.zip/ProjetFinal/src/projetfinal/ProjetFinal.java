/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetfinal;

import com.sun.org.apache.xml.internal.resolver.Catalog;
import java.awt.Event;
import java.util.Scanner;

/**
 *
 * @author MK
 */
public class ProjetFinal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        System.out.println("OMNIPOP");
        System.out.println("=======");
        System.out.println("");
        

        
 

        //Authetification de l'user au programme
        int cpLogin = 0; //On initialise le compteur de login à 0
        System.out.println("Veuillez-vous connecter:");
        
        String userName = login(cpLogin);
        
        
        
        //Si l'utilisateur n'atteint pas les 3 essaies de login alors on execute la fonciton
        String leMotDePasse = motPasse(cpLogin);
        //FinAuthentification

        System.out.println("");
        
        //Lancement du programme
        if (leMotDePasse.equalsIgnoreCase("1234") && userName.equalsIgnoreCase("mlazar") ){
            int rep;
            System.out.println("Bienvenue "+userName);
            System.out.println("");
            
            
            //Si choix
            
            int choix;
            
            //Affichage menu
            do {
                
                System.out.println("Menu principal");
                System.out.println("---------------");   
                choix = menu();
                
                System.out.println(""); 
                
                //Affichage Titre des choix
                if (choix !=6) {
                    titreChoix(choix);
                    System.out.println("");                    
                }
                else
                    System.out.println("Merci d'avoir utilisé OMNIPOP");
                
                
                
   
            } while (choix != 6);
            System.out.println("");
  
        }
        else
            System.out.println("le username "+userName);
            System.out.println("Nombre de tentive atteint! Aurevoir");
            
            
            
    
    //FinMain à ne pas effacer        
    }
    
    //Tableau Cours
    static String tabCours(){
        String a="";
        String tab[][]={{"Automne 2018","Hiver 2019", "Été 2019" },{"Base de données", "Orienté objet", "Structure de données"},{"Algorithme", "Base de données","Orienté objet"},{"","Algorithme",""}};
        for (int i = 0; i < tab.length; i++) {
            for (int j = 0; j < 2; j++) {
                System.out.println(tab[i][j]);
                a=tab[i][j];
                
            }
            
        }
        return a;
    }
    
    
    //Listes des cours
    static void listeCours(String tab[]){
        
        for (int i = 0; i < tab.length; i++) {
            System.out.print(tab[i]+" | ");            
        }
        System.out.println("");
        
    }

    
    //Option du choix
    static void titreChoix(int choixUtil){
        switch (choixUtil){
            
            case 1:
                System.out.println("Cours par session");
                break;
            case 2:
                System.out.println("Listes des cours");
                break;
            case 3:
                System.out.println("Ajout d'un nouvel étudiant");
                break;
            case 4:
                System.out.println("Liste des étudiants");
                break;
            case 5:
                System.out.println("Recherche d'étudiant");
                
            default:
                System.out.println("Choix invalide");
                    
                        
        }
        
    }

    //Menu
    static int menu(){
        Scanner sc = new Scanner(System.in);
        
        //On appelle la fonction ListeMenu qui affiche la liste
        listeMenu();     
        System.out.println("");
        System.out.print("Votre choix: "); 
        System.out.println("");

        while (!sc.hasNextInt()) {
            
            //On appelle la fonction ListeMenu qui affiche la liste
            listeMenu();           
            System.out.println("");
            System.out.print("Votre choix: ");
            sc.next();
            
        } 

        int choix = sc.nextInt();

        return choix;
   
    }
    
    //Listes choix
    static void listeMenu(){
        System.out.println("1. Liste des cours par session");
        System.out.println("2. Afficher tous les cours");
        System.out.println("3. Entrer un nouvel étudiant");
        System.out.println("4. Liste de tous les étudiants");
        System.out.println("5. Rechercher un étudiant");
        System.out.println("6. Quitter le programme");
    }
    
    //Mot de pass
    static String motPasse(int cpPass){
        Scanner sc = new Scanner(System.in);
        
        String motDePasse = new String(); //On cree un objet de type String
        motDePasse = "";
        
        if (cpPass <3) {
            do {

                System.out.print("Mot de passe: ");
                motDePasse = sc.next();
            
                cpPass++;
            
                //Cas d'exception pour afficher le message seulement en cas d'erreur
                if (motDePasse.equalsIgnoreCase("1234") == false) {
                System.out.println("Mot de passe incorrect! Réessayez, il vous reste "+(3-cpPass)+" tentive");                
                }

            } while (motDePasse.equalsIgnoreCase("1234") == false && cpPass<3);
            
        }
        return motDePasse;
    }
    
    static String login(int cpLogin){
        Scanner sc = new Scanner(System.in);
        
        String nomUtilisateur = new String(); //On cree un objet de type String        
        nomUtilisateur = "";
        
        
        
                do {
                
            System.out.print("Login: ");
            nomUtilisateur = sc.next();
            
            cpLogin++;
            
            //Cas d'exception pour afficher le message seulement en cas d'erreur
            if (nomUtilisateur.equalsIgnoreCase("mlazar") == false ) {
                System.out.println("Utilisateur non trouvé! Réessayez, il vous reste "+(3-cpLogin)+" tentive");
            }
 
        }while (nomUtilisateur.equalsIgnoreCase("mlazar")== false && cpLogin<3);
        
        return nomUtilisateur;
    }
    
}
