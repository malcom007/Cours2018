/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 * Author:  mk
 * Created: 2019-06-03
 */



CREATE TABLE Article(
      CodeArticle Varchar(5),
    DesignationArticle Varchar(50),
    CodeCategorie Varchar(5),
    PrixUnitaire Double,
    LastModfied TimeStamp
)



-- CREATE TABLE Person ( 
--   USER_ID       NUMERIC (5)    NOT NULL, 
--   USERNAME      VARCHAR (20)  NOT NULL, 
--   CREATED_BY    VARCHAR (20)  NOT NULL, 
--   CREATED_DATE  DATE          NOT NULL, 
--   PRIMARY KEY ( USER_ID ) 
--  )

